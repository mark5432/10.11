﻿using System.ComponentModel.DataAnnotations;

namespace UsersApi.Moddelsá
{
    public class User
    {
        [Key]
        public Guid Id { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public DateTime CreateTime { get; set; }
    }
}
