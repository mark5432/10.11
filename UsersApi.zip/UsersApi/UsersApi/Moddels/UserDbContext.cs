﻿using Microsoft.EntityFrameworkCore;
using UsersApi.Moddelsá;

namespace UsersApi.Moddels
{
    public class UserDbContext : DbContext
    {
        public UserDbContext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<User> Users { get; set; } = null!;
    }
}
