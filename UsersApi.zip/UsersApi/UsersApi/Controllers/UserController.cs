﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UsersApi.Moddelsá;

namespace UsersApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        [HttpGet]
        public AcceptedResult<UserDto> Post(CreateUserDto createUserDto)
        {

        }
    }

    public class CreateUserDto
    {
    }
}
